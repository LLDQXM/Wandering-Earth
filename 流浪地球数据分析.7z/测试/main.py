import os
import pandas
from pyecharts.charts import Bar, Pie, Line
from pyecharts import options as opts


def get_city(data):
    province = '湖南,湖北,广东,广西、河南、河北、山东、山西,江苏、浙江、江西、黑龙江、新疆,云南、贵州、福建、吉林、安徽,四川、西藏、宁夏、辽宁、青海、甘肃、陕西,内蒙古、台湾,海南,北京'
    province = province.replace('、', ',').split(',')

    arrage = [0 for i in range(40)]
    city_dict = dict(zip(province, arrage))

    for each_city in data['city']:
        if type(each_city) == str:
            for each_pro in province:
                if each_pro in each_city:
                    city_dict[each_pro] += 1
                    break
    temp = city_dict.copy()
    for key in temp.keys():
        if city_dict[key] == 0:
            city_dict.pop(key)
    print(city_dict)
    draw_bar_city(city_dict)


def draw_bar_city(city_dict):
    city_data = [each for each in city_dict.items()]
    city_list = [each for each in city_dict.keys()]
    bar = Bar()
    bar.add_xaxis(city_list)
    bar.add_yaxis('城市', city_data)
    bar.set_global_opts(title_opts=opts.TitleOpts(title='评论来源排行'),
                        xaxis_opts=opts.AxisOpts(axislabel_opts={"rotate": 45}))
    bar.render()


def get_eval(data):
    province = ['力荐', '推荐', '还行', '较差', '很差']
    arrage = [0 for each in range(5)]

    eval_dict = dict(zip(province, arrage))

    for each_eval in data['score']:
        if type(each_eval) == str:
            for each_pro in province:
                if each_pro in each_eval:
                    eval_dict[each_pro] += 1
                    break
    print(eval_dict)
    draw_eval_pie(eval_dict, province)


def draw_eval_pie(eval_dict, province):
    count_list = [each for each in eval_dict.values()]
    pie = Pie()
    pie.add('', [list(eva) for eva in zip(province, count_list)], radius=['30%', '75%'], rosetype="radius")
    pie.set_global_opts(title_opts=opts.TitleOpts(title='饼状图', subtitle='评价饼状图'))
    pie.set_series_opts(label_opts=opts.LabelOpts(formatter="{b}:{d}%"))
    pie.render('eval.html')


def get_date(data):
    score_list = ['力荐', '推荐', '还行', '较差', '很差']
    province = {'力荐': 0, '推荐': 0, '还行': 0, '较差': 0, '很差': 0}
    all_data = {}
    a = data[['score', 'date']]
    date = a['date']
    score = a['score']
    date_list = list(zip(score, date))
    for each_data in date_list:
        if each_data[1] not in all_data and type(each_data[0] == str) and type(each_data[1]) == str:
            temp_score = province.copy()
            for each_score in score_list:
                if each_data[0] == each_score:
                    temp_score[each_score] += 1
                    all_data[each_data[1]] = temp_score
                    break
        elif each_data[1] in all_data and type(each_data[0] == str) and type(each_data[1]) == str:
            for each_score in score_list:
                if each_data[0] == each_score:
                    all_data[each_data[1]][each_score] += 1
                    break
    date_list = sorted(all_data)
    for each in date_list:
        print(each, all_data[each])

    draw_line_date(date_list, all_data)


def draw_line_date(date_list, all_data):
    data1 = []
    data2 = []
    data3 = []
    data4 = []
    data5 = []

    for each_date in date_list:
        data1.append(all_data[each_date]['力荐'])
        data2.append(all_data[each_date]['推荐'])
        data3.append(all_data[each_date]['还行'])
        data4.append(all_data[each_date]['较差'])
        data5.append(all_data[each_date]['很差'])

    line = Line()
    line.add_xaxis(date_list)
    line.add_yaxis('力荐', data1)
    line.add_yaxis('推荐', data2)
    line.add_yaxis('还行', data3)
    line.add_yaxis('较差', data4)
    line.add_yaxis('很差', data5)
    line.set_global_opts(title_opts=opts.TitleOpts(title="折线图", subtitle='时间评价折线图'))
    line.render('date_line.html')


if __name__ == '__main__':
    path = os.getcwd() + '/流浪地球.csv'
    data = pandas.read_csv(path)
    # get_city(data)
    # get_eval(data)
    get_date(data)
